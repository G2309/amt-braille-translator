| Modelo | Obras | F1_onset | F1_note (con offset) | NER | Latencia norm. (media / p90) |
|---|:---:|:---:|:---:|:---:|:---:|
| Basic Pitch (2022) | 20 | 64.75% ± 8.21% | 7.82% ± 3.42% | 63.37% | 0.028 / 0.040 |
| Kong et al. (2021) | 20 | 95.89% ± 2.82% | 33.38% ± 26.56% | 8.01% | 0.088 / 0.088 |
| Onsets and Frames (2018) — linea base bibliografica | — | 94.80% (publicado) | 82.60% (publicado) | — | — |